package com.yagami.diagnostic

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** YAGAMI Diagnostics dark-navy + yellow theme and small view helpers (programmatic UI, no XML). */
object T {
    val bg = Color.parseColor("#070C18")          // page background (near-black navy)
    val bg2 = Color.parseColor("#0A1326")         // panel background
    val card = Color.parseColor("#0E1B33")        // card
    val cardHi = Color.parseColor("#13264A")      // raised card
    val stroke = Color.parseColor("#1C3A66")      // card border
    val strokeHi = Color.parseColor("#2E5C9E")    // brighter border
    val white = Color.parseColor("#E8EEF8")
    val muted = Color.parseColor("#8296B4")
    val yellow = Color.parseColor("#FFD21E")      // primary accent
    val blue = Color.parseColor("#2E7DFF")        // secondary accent
    val green = Color.parseColor("#27C070")
    val red = Color.parseColor("#FF4D5A")
    val cyan = Color.parseColor("#36C6D3")
    val purple = Color.parseColor("#8B5CF6")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun Context.tv(text: CharSequence, size: Float, color: Int, bold: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        setTextColor(color)
        if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
        includeFontPadding = false
    }

fun rounded(color: Int, radius: Float, stroke: Int? = null, strokeW: Int = 2): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        if (stroke != null) setStroke(strokeW, stroke)
    }

fun Context.ripple(content: GradientDrawable, radius: Float): RippleDrawable =
    RippleDrawable(ColorStateList.valueOf(Color.argb(60, 255, 255, 255)),
        content, rounded(Color.WHITE, radius))

fun vgradient(radius: Float, vararg colors: Int): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors).apply { cornerRadius = radius }

fun Context.row(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
fun Context.col(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(w, h, weight)
