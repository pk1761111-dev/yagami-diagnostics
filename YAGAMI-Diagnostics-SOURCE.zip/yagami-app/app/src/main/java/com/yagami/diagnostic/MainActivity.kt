package com.yagami.diagnostic

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private enum class Screen { SPLASH, COMPANY, VEHICLE, DASHBOARD, CONNECT, READ_DTC, LIVE, CLEAR_DTC, ABS, ECU_INFO }

    private val obd = Obd()
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private var screen = Screen.SPLASH
    private val backStack = ArrayDeque<Screen>()
    private var brand: String? = null
    private var model: String? = null
    private var mode = "bt"            // "bt" or "wifi"
    private var liveLoop: Runnable? = null

    private fun prefs() = getSharedPreferences("yagami", MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#070C18")
        window.navigationBarColor = Color.parseColor("#070C18")
        mode = prefs().getString("mode", "bt") ?: "bt"
        brand = prefs().getString("brand", null)
        model = prefs().getString("model", null)
        show(Screen.SPLASH)
    }

    override fun onDestroy() { super.onDestroy(); io.execute { obd.close() } }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        stopLive()
        val prev = backStack.removeLastOrNull()
        if (prev == null) super.onBackPressed() else show(prev)
    }

    private fun navigate(s: Screen) {
        if (s != screen) backStack.addLast(screen)
        show(s)
    }

    private fun show(s: Screen) {
        stopLive()
        screen = s
        when (s) {
            Screen.SPLASH -> buildSplash()
            Screen.COMPANY -> buildCompany()
            Screen.VEHICLE -> buildVehicle()
            Screen.DASHBOARD -> buildDashboard()
            Screen.CONNECT -> buildConnect()
            Screen.READ_DTC -> buildReadDtc()
            Screen.LIVE -> buildLive()
            Screen.CLEAR_DTC -> buildClearDtc()
            Screen.ABS -> buildAbs()
            Screen.ECU_INFO -> buildEcuInfo()
        }
    }

    // ---------------- shared chrome ----------------

    private fun page(scroll: Boolean = true): Pair<LinearLayout, LinearLayout> {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(T.bg) }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(20)) }
        if (scroll) {
            val sv = ScrollView(this).apply { isFillViewport = true }
            sv.addView(body); root.addView(sv, lp(-1, 0, 1f))
        } else {
            root.addView(body, lp(-1, 0, 1f))
        }
        return root to body
    }

    private fun topBar(title: String, sub: String? = null, back: Boolean = true, home: Boolean = true): LinearLayout {
        val bar = row().apply { setPadding(dp(14), dp(14), dp(14), dp(10)) }
        if (back) {
            bar.addView(tv("‹", 26f, T.white, true).apply {
                gravity = Gravity.CENTER
                background = ripple(rounded(Color.TRANSPARENT, dpf(20f)), dpf(20f)); isClickable = true
                setOnClickListener { onBackPressed() }
            }, lp(dp(40), dp(40)))
        }
        val c = col().apply { gravity = Gravity.CENTER_HORIZONTAL }
        c.addView(tv(title, 18f, T.white, true))
        if (sub != null) c.addView(tv(sub, 11.5f, T.muted))
        bar.addView(c, lp(0, -2, 1f))
        if (home) {
            bar.addView(tv("⌂", 22f, T.yellow, true).apply {
                gravity = Gravity.CENTER; isClickable = true
                background = ripple(rounded(Color.TRANSPARENT, dpf(20f)), dpf(20f))
                setOnClickListener { backStack.clear(); show(Screen.DASHBOARD) }
            }, lp(dp(40), dp(40)))
        } else {
            bar.addView(View(this), lp(dp(40), dp(40)))
        }
        return bar
    }

    private fun footerBrand(): TextView = tv("YAGAMI\nWe Give Best Quality Connector", 11f, T.muted, false).apply {
        gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(4))
    }

    private fun primary(text: String, action: () -> Unit): TextView = tv(text, 15.5f, Color.parseColor("#071018"), true).apply {
        gravity = Gravity.CENTER; isClickable = true
        background = ripple(rounded(T.yellow, dpf(12f)), dpf(12f))
        setOnClickListener { action() }
    }

    private fun ghost(text: String, action: () -> Unit): TextView = tv(text, 15f, T.white, true).apply {
        gravity = Gravity.CENTER; isClickable = true
        background = ripple(rounded(T.card, dpf(12f), T.stroke), dpf(12f))
        setOnClickListener { action() }
    }

    // ---------------- Splash ----------------

    private fun buildSplash() {
        val root = FrameLayout(this).apply { setBackgroundColor(T.bg) }
        val c = col().apply { gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(24), 0, dp(24), 0) }
        val wrap = FrameLayout(this)
        wrap.addView(c, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        c.addView(LogoView(this), lp(dp(120), dp(120)))
        c.addView(tv("YAGAMI", 40f, T.yellow, true).apply { gravity = Gravity.CENTER; letterSpacing = 0.08f; setPadding(0, dp(10), 0, 0) }, lp(-2, -2))
        c.addView(tv("DIAGNOSTICS", 18f, T.white, true).apply { gravity = Gravity.CENTER; letterSpacing = 0.34f }, lp(-2, -2))
        c.addView(tv("Smart Vehicle Scanner for Engine & ABS", 12.5f, T.muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(14), 0, 0) }, lp(-2, -2))
        c.addView(tv("Initializing… Please Wait", 11.5f, T.muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(40), 0, 0) }, lp(-2, -2))
        root.addView(wrap, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        ui.postDelayed({ if (screen == Screen.SPLASH) { backStack.clear(); show(Screen.COMPANY) } }, 1400)
    }

    // ---------------- Select Company ----------------

    private fun buildCompany() {
        val (root, body) = page()
        body.addView(tv("Select Company", 22f, T.white, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) }, lp(-1, -2))
        body.addView(tv("Choose Your Vehicle Brand", 12.5f, T.muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(14)) }, lp(-1, -2))
        for (b in Data.brands.keys) {
            val style = Data.brandStyle[b] ?: ("#7A8594" to b.take(2).uppercase())
            val selected = b == brand
            val rrow = row().apply {
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = ripple(rounded(T.card, dpf(14f), if (selected) T.yellow else T.stroke), dpf(14f))
                isClickable = true
                setOnClickListener {
                    brand = b; model = null
                    prefs().edit().putString("brand", b).remove("model").apply()
                    navigate(Screen.VEHICLE)
                }
            }
            rrow.addView(BrandBadge(this, style.second, style.first), lp(dp(40), dp(40)).apply { marginEnd = dp(14) })
            rrow.addView(tv(if (b == "Others") "Others" else b, 16f, if (selected) T.yellow else T.white, true), lp(0, -2, 1f))
            rrow.addView(tv("›", 20f, T.muted, true), lp(-2, -2))
            body.addView(rrow, lp(-1, -2).apply { bottomMargin = dp(10) })
        }
        body.addView(footerBrand(), lp(-1, -2))
        setContentView(root)
    }

    // ---------------- Select Vehicle ----------------

    private fun buildVehicle() {
        val b = brand ?: return show(Screen.COMPANY)
        val (root, body) = page()
        body.addView(tv("Select Vehicle", 22f, T.white, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) }, lp(-1, -2))
        body.addView(tv("Choose Your Model", 12.5f, T.muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(12)) }, lp(-1, -2))
        // brand chip
        val style = Data.brandStyle[b] ?: ("#7A8594" to b.take(2).uppercase())
        val chip = row().apply {
            setPadding(dp(14), dp(10), dp(14), dp(10)); gravity = Gravity.CENTER
            background = rounded(T.card, dpf(12f), T.stroke)
        }
        chip.addView(BrandBadge(this, style.second, style.first), lp(dp(30), dp(30)).apply { marginEnd = dp(10) })
        chip.addView(tv(b, 16f, T.white, true), lp(-2, -2))
        body.addView(chip, lp(-1, -2).apply { bottomMargin = dp(12) })

        for (m in Data.brands[b].orEmpty()) {
            val selected = m == model
            val rrow = row().apply {
                setPadding(dp(14), dp(14), dp(14), dp(14))
                background = ripple(rounded(T.card, dpf(14f), if (selected) T.yellow else T.stroke), dpf(14f))
                isClickable = true
                setOnClickListener {
                    model = m; prefs().edit().putString("model", m).apply()
                    buildVehicle()   // refresh highlight
                }
            }
            rrow.addView(tv(m, 15f, if (selected) T.yellow else T.white, selected), lp(0, -2, 1f))
            rrow.addView(tv(if (selected) "✓" else "›", 18f, if (selected) T.yellow else T.muted, true), lp(-2, -2))
            body.addView(rrow, lp(-1, -2).apply { bottomMargin = dp(10) })
        }

        val btns = row().apply { setPadding(0, dp(8), 0, 0) }
        btns.addView(ghost("← Back") { onBackPressed() }, lp(0, dp(50), 1f).apply { marginEnd = dp(10) })
        btns.addView(primary("Next →") {
            if (model == null) toast("Pehle model chunein") else { backStack.clear(); backStack.addLast(Screen.COMPANY); show(Screen.DASHBOARD) }
        }, lp(0, dp(50), 1f))
        body.addView(btns, lp(-1, -2))
        setContentView(root)
    }

    // ---------------- Dashboard ----------------

    private fun buildDashboard() {
        val (root, body) = page()
        // top bar: logo + name + gear
        val bar = row().apply { setPadding(dp(4), dp(8), dp(4), dp(12)) }
        bar.addView(LogoView(this), lp(dp(40), dp(40)).apply { marginEnd = dp(10) })
        val nm = col()
        nm.addView(tv("YAGAMI", 18f, T.yellow, true).apply { letterSpacing = 0.06f })
        nm.addView(tv("DIAGNOSTICS", 10f, T.white, true).apply { letterSpacing = 0.22f })
        bar.addView(nm, lp(0, -2, 1f))
        bar.addView(tv("⚙", 20f, T.muted, true).apply { gravity = Gravity.CENTER; isClickable = true
            background = ripple(rounded(Color.TRANSPARENT, dpf(18f)), dpf(18f))
            setOnClickListener { navigate(Screen.CONNECT) } }, lp(dp(40), dp(40)))
        body.addView(bar, lp(-1, -2))

        // connection status
        val st = row().apply { setPadding(dp(4), 0, dp(4), dp(10)) }
        val dot = if (obd.connected) "●" else "○"
        st.addView(tv("$dot ${if (obd.connected) "Connected" else "Not connected"}", 13f, if (obd.connected) T.green else T.muted, true), lp(0, -2, 1f))
        st.addView(tv(obd.adapterName, 12f, T.cyan, true).apply {
            setPadding(dp(10), dp(4), dp(10), dp(4)); background = rounded(T.card, dpf(10f), T.stroke)
        }, lp(-2, -2))
        body.addView(st, lp(-1, -2))

        // bike title + art
        body.addView(tv("${brand ?: "—"}  ${model ?: ""}".trim(), 17f, T.white, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(6)) }, lp(-1, -2))
        val art = FrameLayout(this).apply {
            background = vgradient(dpf(16f), Color.parseColor("#0E1B33"), Color.parseColor("#0A1326"))
        }
        val absGlow = tv("((ABS))", 20f, T.yellow, true).apply { gravity = Gravity.CENTER }
        art.addView(tv("🏍", 56f, T.white).apply { gravity = Gravity.CENTER }, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        art.addView(absGlow, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(18) })
        body.addView(art, lp(-1, dp(130)).apply { bottomMargin = dp(12) })

        // action grid 2 columns
        val actions = listOf(
            Triple("Read DTC", "🔍", T.blue) to { ensureConnected { navigate(Screen.READ_DTC) } },
            Triple("Clear DTC", "🧹", T.red) to { ensureConnected { navigate(Screen.CLEAR_DTC) } },
            Triple("Live Data", "📈", T.green) to { ensureConnected { navigate(Screen.LIVE) } },
            Triple("ECU Info", "🧠", T.cyan) to { ensureConnected { navigate(Screen.ECU_INFO) } },
            Triple("ABS", "🛞", T.yellow) to { ensureConnected { navigate(Screen.ABS) } },
            Triple("Connect", "🔌", T.purple) to { navigate(Screen.CONNECT) }
        )
        var i = 0
        while (i < actions.size) {
            val r = row()
            for (j in 0 until 2) {
                val a = actions.getOrNull(i + j)
                if (a != null) {
                    r.addView(actionTile(a.first.first, a.first.second, a.first.third, a.second),
                        lp(0, dp(96), 1f).apply { if (j == 0) marginEnd = dp(10) })
                } else r.addView(View(this), lp(0, dp(96), 1f))
            }
            body.addView(r, lp(-1, -2).apply { bottomMargin = dp(10) })
            i += 2
        }

        body.addView(tv(if (obd.connected) "✓ Ready to Diagnose" else "Connect an ELM327 adapter to begin",
            13f, if (obd.connected) T.green else T.muted, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(T.card, dpf(12f), T.stroke)
        }, lp(-1, -2))
        body.addView(footerBrand(), lp(-1, -2))
        setContentView(root)
    }

    private fun actionTile(label: String, icon: String, accent: Int, action: () -> Unit): LinearLayout {
        val t = col().apply {
            gravity = Gravity.CENTER
            background = ripple(rounded(T.card, dpf(14f), T.stroke), dpf(14f))
            isClickable = true
            setOnClickListener { action() }
        }
        t.addView(tv(icon, 24f, accent).apply { gravity = Gravity.CENTER }, lp(-2, -2))
        t.addView(tv(label, 13.5f, T.white, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }, lp(-2, -2))
        return t
    }

    private fun ensureConnected(then: () -> Unit) {
        if (obd.connected) then() else { toast("Pehle adapter connect karein"); navigate(Screen.CONNECT) }
    }

    // ---------------- Connect ----------------

    private var connectInfo: TextView? = null

    private fun buildConnect() {
        val (root, body) = page()
        body.addView(topBar("Connect Adapter", "ELM327 Bluetooth / Wi-Fi"), lp(-1, -2))

        val info = tv(if (obd.connected) "Connected to ${obd.adapterName}" else "Not connected", 13.5f,
            if (obd.connected) T.green else T.muted, true)
        connectInfo = info
        body.addView(card().apply { addView(info) }, lp(-1, -2).apply { bottomMargin = dp(12) })

        // mode toggle
        val toggle = row()
        toggle.addView(modeBtn("Bluetooth", "bt"), lp(0, dp(46), 1f).apply { marginEnd = dp(8) })
        toggle.addView(modeBtn("Wi-Fi", "wifi"), lp(0, dp(46), 1f))
        body.addView(toggle, lp(-1, -2).apply { bottomMargin = dp(12) })

        if (mode == "bt") {
            body.addView(tv("PAIRED ELM / OBD ADAPTERS", 10.5f, T.muted, true).apply { letterSpacing = 0.1f; setPadding(dp(2), 0, 0, dp(6)) }, lp(-1, -2))
            val list = col()
            body.addView(list, lp(-1, -2))
            fillBonded(list)
            body.addView(ghost("Open Bluetooth Settings") {
                try { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } catch (e: Exception) {}
            }, lp(-1, dp(50)).apply { topMargin = dp(10) })
        } else {
            body.addView(tv("ADAPTER IP", 10.5f, T.muted, true).apply { letterSpacing = 0.1f; setPadding(dp(2), 0, 0, dp(6)) }, lp(-1, -2))
            val ip = field(prefs().getString("ip", "192.168.0.10") ?: "192.168.0.10")
            body.addView(ip, lp(-1, dp(50)).apply { bottomMargin = dp(10) })
            body.addView(tv("PORT", 10.5f, T.muted, true).apply { letterSpacing = 0.1f; setPadding(dp(2), 0, 0, dp(6)) }, lp(-1, -2))
            val port = field(prefs().getString("port", "35000") ?: "35000")
            body.addView(port, lp(-1, dp(50)).apply { bottomMargin = dp(12) })
            body.addView(primary("Connect (Wi-Fi)") {
                val ipv = ip.text.toString().trim(); val pv = port.text.toString().trim().toIntOrNull() ?: 35000
                prefs().edit().putString("ip", ipv).putString("port", pv.toString()).putString("mode", "wifi").apply()
                mode = "wifi"
                doConnect { obd.connectWifi(ipv, pv) }
            }, lp(-1, dp(52)))
        }
        setContentView(root)
    }

    private fun modeBtn(label: String, m: String): TextView = tv(label, 14f, if (mode == m) Color.parseColor("#071018") else T.white, true).apply {
        gravity = Gravity.CENTER; isClickable = true
        background = ripple(rounded(if (mode == m) T.yellow else T.card, dpf(12f), T.stroke), dpf(12f))
        setOnClickListener { mode = m; prefs().edit().putString("mode", m).apply(); show(Screen.CONNECT) }
    }

    private fun fillBonded(list: LinearLayout) {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.BLUETOOTH_CONNECT), 1)
            list.addView(tv("Bluetooth permission needed — allow and reopen.", 12.5f, T.muted), lp(-1, -2))
            return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) {
            list.addView(tv("Turn on Bluetooth, then reopen this screen.", 12.5f, T.muted), lp(-1, -2))
            return
        }
        val bonded = try { adapter.bondedDevices } catch (e: SecurityException) { null }
        if (bonded.isNullOrEmpty()) {
            list.addView(tv("No paired devices. Pair your ELM327 in Settings first.", 12.5f, T.muted), lp(-1, -2))
            return
        }
        for (d in bonded) {
            val name = try { d.name ?: "Device" } catch (e: SecurityException) { "Device" }
            val addr = d.address
            val rrow = row().apply {
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = ripple(rounded(T.card, dpf(12f), T.stroke), dpf(12f)); isClickable = true
                setOnClickListener {
                    prefs().edit().putString("mode", "bt").putString("bt", addr).apply(); mode = "bt"
                    doConnect { obd.connectBluetooth(addr) }
                }
            }
            val cc = col()
            cc.addView(tv(name, 15f, T.white, true))
            cc.addView(tv(addr, 11f, T.muted))
            rrow.addView(cc, lp(0, -2, 1f))
            rrow.addView(tv("Connect", 12.5f, Color.parseColor("#071018"), true).apply {
                setPadding(dp(12), dp(6), dp(12), dp(6)); background = rounded(T.yellow, dpf(9f))
            }, lp(-2, -2))
            list.addView(rrow, lp(-1, -2).apply { bottomMargin = dp(8) })
        }
    }

    private fun doConnect(connector: () -> Boolean) {
        connectInfo?.text = "Connecting…"; connectInfo?.setTextColor(T.yellow)
        io.execute {
            val ok = connector()
            val inited = if (ok) obd.initEngine() else false
            ui.post {
                if (ok) {
                    obd.adapterName = "ELM327"
                    connectInfo?.text = if (inited) "Connected — engine ECU responding" else "Adapter connected (ECU not responding yet)"
                    connectInfo?.setTextColor(if (inited) T.green else T.yellow)
                    toast(if (inited) "Connected ✓" else "Adapter connected")
                    backStack.clear(); backStack.addLast(Screen.COMPANY); show(Screen.DASHBOARD)
                } else {
                    connectInfo?.text = "Connection failed — check the adapter"
                    connectInfo?.setTextColor(T.red)
                    toast("Connect nahi hua")
                }
            }
        }
    }

    // ---------------- Read DTC ----------------

    private fun buildReadDtc() {
        val (root, body) = page()
        body.addView(topBar("Read Fault Codes", "${brand ?: ""} ${model ?: ""}".trim()), lp(-1, -2))
        val status = tv("🔍  Scanning ECU… please wait", 15f, T.white, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(20), 0, dp(10)) }
        body.addView(status, lp(-1, -2))
        val listCard = col()
        body.addView(listCard, lp(-1, -2))
        setContentView(root)

        io.execute {
            val stored = obd.readStored()
            val pending = obd.readPending()
            val perm = obd.readPermanent()
            ui.post {
                val all = ArrayList<Pair<String, String>>()
                stored.forEach { all.add(it to "Stored") }
                pending.forEach { all.add(it to "Pending") }
                perm.forEach { all.add(it to "Permanent") }
                if (all.isEmpty()) {
                    status.text = "✓ No fault codes found"
                    status.setTextColor(T.green)
                    listCard.addView(card().apply {
                        addView(tv("ECU reported no stored, pending or permanent fault codes.", 13.5f, T.white))
                    }, lp(-1, -2).apply { topMargin = dp(8) })
                } else {
                    status.text = "Found ${all.size} fault code(s)"
                    status.setTextColor(T.yellow)
                    for ((code, kind) in all) listCard.addView(dtcCard(code, kind), lp(-1, -2).apply { topMargin = dp(10) })
                }
            }
        }
    }

    private fun dtcCard(code: String, kind: String): LinearLayout {
        val c = card()
        val head = row()
        head.addView(tv(code, 18f, T.red, true), lp(0, -2, 1f))
        head.addView(tv(kind, 11f, T.muted, true).apply {
            setPadding(dp(10), dp(4), dp(10), dp(4)); background = rounded(T.cardHi, dpf(9f), T.stroke)
        }, lp(-2, -2))
        c.addView(head)
        c.addView(tv(Data.describe(code), 13.5f, T.white).apply { setPadding(0, dp(8), 0, 0) })
        return c
    }

    // ---------------- Clear DTC ----------------

    private fun buildClearDtc() {
        val (root, body) = page()
        body.addView(topBar("Clear Fault Codes"), lp(-1, -2))
        body.addView(tv("⚠", 44f, T.yellow).apply { gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(6)) }, lp(-1, -2))
        body.addView(tv("Are you sure?", 20f, T.white, true).apply { gravity = Gravity.CENTER }, lp(-1, -2))
        body.addView(tv("This will clear all stored fault codes and turn off the check-engine (MIL) light.", 13f, T.muted).apply {
            gravity = Gravity.CENTER; setPadding(dp(16), dp(8), dp(16), dp(18))
        }, lp(-1, -2))
        val result = tv("", 13.5f, T.green, true).apply { gravity = Gravity.CENTER }
        val btns = row()
        btns.addView(ghost("Cancel") { onBackPressed() }, lp(0, dp(52), 1f).apply { marginEnd = dp(10) })
        btns.addView(primary("Yes, Clear") {
            result.text = "Clearing…"; result.setTextColor(T.yellow)
            io.execute {
                val reply = obd.clear()
                val ok = reply.joinToString(" ").uppercase().contains("44")
                ui.post {
                    if (ok) { result.text = "✓ Fault codes cleared successfully"; result.setTextColor(T.green) }
                    else { result.text = "ECU did not confirm clear. Raw: " + reply.joinToString(" ").ifBlank { "no reply" }; result.setTextColor(T.red) }
                }
            }
        }, lp(0, dp(52), 1f))
        body.addView(btns, lp(-1, -2))
        body.addView(result, lp(-1, -2).apply { topMargin = dp(16) })
        setContentView(root)
    }

    // ---------------- Live Data ----------------

    private val livePids = listOf(
        LivePid("rpm", "Engine RPM", "0C", "rpm", 9000f, T.yellow),
        LivePid("speed", "Speed", "0D", "km/h", 160f, T.blue),
        LivePid("coolant", "Engine Temp", "05", "°C", 150f, T.red),
        LivePid("throttle", "Throttle", "11", "%", 100f, T.green),
        LivePid("iat", "Intake Air", "0F", "°C", 100f, T.cyan),
        LivePid("load", "Engine Load", "04", "%", 100f, T.purple)
    )

    private val gauges = HashMap<String, GaugeView>()
    private var battView: TextView? = null

    private fun buildLive() {
        gauges.clear()
        val (root, body) = page()
        body.addView(topBar("Live Data", "${brand ?: ""} ${model ?: ""}".trim()), lp(-1, -2))
        var i = 0
        while (i < livePids.size) {
            val r = row()
            for (j in 0 until 2) {
                val p = livePids.getOrNull(i + j)
                if (p != null) {
                    val cell = col().apply { gravity = Gravity.CENTER_HORIZONTAL
                        background = rounded(T.card, dpf(14f), T.stroke); setPadding(dp(8), dp(12), dp(8), dp(12)) }
                    cell.addView(tv(p.label, 12f, T.muted, true).apply { gravity = Gravity.CENTER }, lp(-2, -2))
                    val g = GaugeView(this, p.accent).apply { label = p.label; unit = p.unit; max = p.max; display = "—" }
                    gauges[p.key] = g
                    cell.addView(g, lp(dp(120), dp(84)))
                    r.addView(cell, lp(0, -2, 1f).apply { if (j == 0) marginEnd = dp(10) })
                } else r.addView(View(this), lp(0, -2, 1f))
            }
            body.addView(r, lp(-1, -2).apply { bottomMargin = dp(10) })
            i += 2
        }
        val bv = tv("Battery: —", 14f, T.white, true).apply { gravity = Gravity.CENTER; setPadding(dp(12), dp(12), dp(12), dp(12)); background = rounded(T.card, dpf(12f), T.stroke) }
        battView = bv
        body.addView(bv, lp(-1, -2))
        body.addView(tv("Values update live with the engine running.", 11.5f, T.muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) }, lp(-1, -2))
        setContentView(root)
        startLive()
    }

    private fun startLive() {
        stopLive()
        val loop = object : Runnable {
            override fun run() {
                io.execute {
                    val vals = HashMap<String, Pair<Float, String>>()
                    for (p in livePids) {
                        val pl = obd.livePid(p.pid) ?: continue
                        val v = computeLive(p.key, pl) ?: continue
                        vals[p.key] = v
                    }
                    val batt = obd.battery()
                    ui.post {
                        for ((k, v) in vals) gauges[k]?.let { it.value = v.first; it.display = v.second }
                        if (batt.isNotBlank()) battView?.text = "Battery: $batt"
                    }
                }
                ui.postDelayed(this, 700)
            }
        }
        liveLoop = loop
        ui.postDelayed(loop, 150)
    }

    private fun stopLive() { liveLoop?.let { ui.removeCallbacks(it) }; liveLoop = null }

    private fun computeLive(key: String, p: IntArray): Pair<Float, String>? {
        if (p.isEmpty()) return null
        val a = p[0]; val b = if (p.size > 1) p[1] else 0
        return when (key) {
            "rpm" -> { val v = (a * 256 + b) / 4f; v to "${Math.round(v)}" }
            "speed" -> { val v = a.toFloat(); v to "${a}" }
            "coolant", "iat" -> { val v = (a - 40).toFloat(); v to "${a - 40}" }
            "throttle", "load" -> { val v = a * 100f / 255f; v to "${Math.round(v)}" }
            else -> null
        }
    }

    // ---------------- ECU Info ----------------

    private fun buildEcuInfo() {
        val (root, body) = page()
        body.addView(topBar("ECU Information"), lp(-1, -2))
        val c = card()
        val rows = c
        body.addView(c, lp(-1, -2))
        val lbl = tv("Reading…", 14f, T.muted); rows.addView(lbl)
        setContentView(root)
        io.execute {
            val vin = obd.readVin()
            val proto = obd.protocol
            val batt = obd.battery()
            ui.post {
                rows.removeAllViews()
                rows.addView(kv("VIN", vin ?: "Not reported"))
                rows.addView(kv("Protocol", if (proto.isBlank()) "—" else proto))
                rows.addView(kv("Adapter", obd.adapterName))
                rows.addView(kv("Battery", if (batt.isBlank()) "—" else batt))
                rows.addView(kv("Bike", "${brand ?: ""} ${model ?: ""}".trim()))
            }
        }
    }

    private fun kv(k: String, v: String): LinearLayout {
        val r = row().apply { setPadding(0, dp(8), 0, dp(8)) }
        r.addView(tv(k, 13f, T.muted, true), lp(dp(110), -2))
        r.addView(tv(v, 13.5f, T.white, true), lp(0, -2, 1f))
        return r
    }

    // ---------------- ABS ----------------

    private fun buildAbs() {
        val (root, body) = page()
        body.addView(topBar("ABS Diagnostics", "${brand ?: ""} ${model ?: ""}".trim()), lp(-1, -2))
        body.addView(tv("((ABS))", 30f, T.yellow, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(14)) }, lp(-1, -2))

        val out = tv("", 13f, T.white).apply { typeface = Typeface.MONOSPACE }
        body.addView(ghost("🔍  Read ABS DTC (real probe)") {
            out.text = "Probing ABS (headers on)…"
            io.execute {
                val raw = obd.absProbe()
                ui.post {
                    out.text = if (Elm.isNoData(raw))
                        "ABS ECU did not respond.\n\nMost bikes' ABS unit uses a separate address/protocol that a generic ELM327 cannot reach without the correct ABS ECU address. Raw reply:\n" + raw.joinToString("\n").ifBlank { "(empty)" }
                    else
                        "Raw reply (headers on):\n" + raw.joinToString("\n")
                }
            }
        }, lp(-1, dp(50)).apply { bottomMargin = dp(10) })

        body.addView(card().apply { addView(out) }, lp(-1, -2))
        body.addView(tv("Note: this app never fakes an ABS result. If the ABS unit does not answer, its address/protocol is not available to a generic adapter.", 11.5f, T.muted).apply { setPadding(dp(2), dp(12), dp(2), 0) }, lp(-1, -2))
        body.addView(footerBrand(), lp(-1, -2))
        setContentView(root)
    }

    // ---------------- helpers ----------------

    private fun card(): LinearLayout = col().apply {
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = rounded(T.card, dpf(14f), T.stroke)
    }

    private fun field(value: String): EditText = EditText(this).apply {
        setText(value); textSize = 15f; setSingleLine(true)
        setTextColor(T.white); setHintTextColor(T.muted)
        setPadding(dp(14), 0, dp(14), 0)
        background = rounded(T.card, dpf(10f), T.stroke)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (screen == Screen.CONNECT) show(Screen.CONNECT)
    }

    data class LivePid(val key: String, val label: String, val pid: String, val unit: String, val max: Float, val accent: Int)
}
