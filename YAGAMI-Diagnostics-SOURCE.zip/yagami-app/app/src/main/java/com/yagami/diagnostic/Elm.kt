package com.yagami.diagnostic

/** ELM327 / OBD-II response parsing: DTC decoding, VIN, and live-value math. Pure logic, no Android. */
object Elm {

    private const val HEX = "0123456789ABCDEF"

    /** SAE J2012 two-byte DTC -> code string, e.g. 0x01,0x33 -> "P0133". */
    fun dtcFromBytes(a: Int, b: Int): String {
        val letters = charArrayOf('P', 'C', 'B', 'U')
        val l = letters[(a shr 6) and 0x3]
        val d1 = (a shr 4) and 0x3
        val d2 = a and 0xF
        val d3 = (b shr 4) and 0xF
        val d4 = b and 0xF
        return "%c%d%X%X%X".format(l, d1, d2, d3, d4)
    }

    /** Collect clean hex bytes from raw ELM lines, dropping prompts, frame indices and ISO-TP length tokens. */
    private fun bytesOf(lines: List<String>): List<Int> {
        val out = ArrayList<Int>()
        for (raw in lines) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            val up = line.uppercase()
            if (up.contains("NO DATA") || up.contains("UNABLE") || up.contains("SEARCHING") ||
                up.contains("ERROR") || up.contains("STOPPED") || up.contains("?") || up == ">") continue
            for (tok in up.split(Regex("\\s+"))) {
                if (tok.endsWith(":")) continue                     // frame index like "0:"
                if (tok.length == 3 && tok.all { it.isDigit() }) continue  // ISO-TP length like "009"
                if (tok.length == 2 && tok.all { it in HEX }) out.add(tok.toInt(16))
            }
        }
        return out
    }

    /** Decode stored/pending/permanent DTCs from a mode 03/07/0A reply. */
    fun parseDtcs(lines: List<String>, mode: Int): List<String> {
        val resp = mode + 0x40
        val bytes = bytesOf(lines)
        var i = bytes.indexOf(resp)
        if (i < 0) return emptyList()
        i++
        // A CAN reply carries a DTC-count byte right after the response byte; skip it when it fits.
        if (i < bytes.size) {
            val cnt = bytes[i]
            val remaining = bytes.size - (i + 1)
            if (cnt in 0..20 && remaining >= cnt * 2) i++
        }
        val out = ArrayList<String>()
        while (i + 1 < bytes.size) {
            val a = bytes[i]; val b = bytes[i + 1]; i += 2
            if (a == 0 && b == 0) continue
            out.add(dtcFromBytes(a, b))
        }
        return out.distinct()
    }

    /** True if the reply clearly means "no ECU answer / can't communicate". */
    fun isNoData(lines: List<String>): Boolean {
        val j = lines.joinToString(" ").uppercase()
        return j.contains("NO DATA") || j.contains("UNABLE TO CONNECT") || j.contains("CAN ERROR") ||
            j.contains("BUS INIT") || j.isBlank()
    }

    /** VIN from a mode 09 PID 02 reply (49 02 ...), ASCII, 17 chars. */
    fun parseVin(lines: List<String>): String? {
        val bytes = bytesOf(lines)
        var i = bytes.indexOf(0x49)
        if (i < 0 || i + 1 >= bytes.size || bytes[i + 1] != 0x02) return null
        i += 2
        if (i < bytes.size && bytes[i] <= 0x05) i++   // message-count byte
        val sb = StringBuilder()
        while (i < bytes.size) {
            val c = bytes[i]; i++
            if (c in 0x20..0x7E) sb.append(c.toChar())
        }
        val vin = sb.toString().filter { it.isLetterOrDigit() }
        return if (vin.length >= 11) vin.take(17) else null
    }

    /** First data byte of a mode-01 PID reply (e.g. 41 0C xx yy). Returns the payload bytes after "41 <pid>". */
    fun pidPayload(lines: List<String>, pid: Int): IntArray? {
        val bytes = bytesOf(lines)
        var i = 0
        while (i + 1 < bytes.size) {
            if (bytes[i] == 0x41 && bytes[i + 1] == pid) {
                val rest = bytes.subList(i + 2, bytes.size)
                return rest.toIntArray()
            }
            i++
        }
        return null
    }

    fun isHex(s: String): Boolean = s.isNotEmpty() && s.all { it.uppercaseChar() in HEX }
}
