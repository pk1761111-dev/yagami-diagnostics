# YAGAMI Diagnostics — Android App (source)

Smart Vehicle Scanner for Engine & ABS (ELM327 Bluetooth / Wi-Fi OBD-II).
New YAGAMI interface, **public (no login)**, real OBD-II diagnostics.

## APK kaise banayein — bina PC ke, FREE (GitHub)

1. **github.com** par jao, apne account (pk1761111-dev) se login karo.
2. **New repository** banao (naam: `yagami-diagnostics`), **Public** rakho, Create.
3. Repo me **Add file → Upload files** → is folder ki **saari files/folders** upload karo
   (ya zip extract karke drag-drop). Commit.
4. Upar **Actions** tab kholo → "Build APK" workflow apne-aap chalega (~4-6 min).
   (Pehli baar "I understand my workflows, go ahead" par click karna pad sakta hai.)
5. Jab tick (✓) aa jaye → us run ko kholo → neeche **Artifacts** me
   **YAGAMI-Diagnostics-APK** download karo → zip kholo → andar `app-debug.apk`.
6. Wo APK phone me install karo. Ho gaya.

## Ya Android Studio se
Android Studio me ye folder **Open** karo → **Build → Build Bundle(s)/APK(s) → Build APK(s)** →
`app/build/outputs/apk/debug/app-debug.apk`.

## Features
- Select Company → Select Vehicle → Dashboard (Read DTC, Clear DTC, Live Data, ECU Info, ABS)
- Real ELM327 over **Bluetooth (SPP)** or **Wi-Fi (TCP)**
- Read / clear fault codes (OBD-II mode 03/07/0A/04), VIN, live gauges (RPM/Speed/Temp/Throttle…)
- ABS: honest read-only probe (never fakes a result)
- Public — no id/password

## Notes
- minSdk 26 (Android 8.0+), targetSdk 34.
- Brand emblems are original designs (no trademark logos).
- Bluetooth needs the "Nearby devices" permission on Android 12+.
