plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.yagami.diagnostic"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.yagami.diagnostic"
        minSdk = 26
        targetSdk = 34
        versionCode = 30
        versionName = "2.0.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {}
